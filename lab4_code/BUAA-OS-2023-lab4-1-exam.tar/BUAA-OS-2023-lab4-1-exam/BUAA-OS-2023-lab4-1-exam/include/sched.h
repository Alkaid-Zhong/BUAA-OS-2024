#ifndef __SCHED_H__
#define __SCHED_H__

void schedule(int yield) __attribute__((noreturn));

#endif /* __SCHED_H__ */
